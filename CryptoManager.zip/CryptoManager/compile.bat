@echo off
echo ========================================
echo  Crypto Manager Pro - Compilation
echo ========================================
echo.

cd src
echo Compiling Java files...
javac com/cryptomanager/*.java

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================
    echo  Compilation successful!
    echo ========================================
    echo.
    echo You can now run the application using:
    echo   run.bat
    echo.
) else (
    echo.
    echo ========================================
    echo  Compilation failed!
    echo ========================================
    echo.
    echo Please check the error messages above.
    echo.
)

pause
