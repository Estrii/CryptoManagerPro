@echo off
echo ========================================
echo  Crypto Manager Pro
echo ========================================
echo.
echo Starting application...
echo.

cd src
java com.cryptomanager.CryptoManagerApp

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ========================================
    echo  Error starting application!
    echo ========================================
    echo.
    echo Please make sure you have compiled the project first using:
    echo   compile.bat
    echo.
    pause
)
