#!/bin/bash

echo "========================================"
echo " Creating JAR file..."
echo "========================================"
echo ""

cd src
jar cvfm ../CryptoManagerPro.jar ../MANIFEST.MF com/cryptomanager/*.class

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================"
    echo " JAR file created successfully!"
    echo "========================================"
    echo ""
    echo "You can now run the application using:"
    echo "  java -jar CryptoManagerPro.jar"
    echo ""
else
    echo ""
    echo "========================================"
    echo " JAR creation failed!"
    echo "========================================"
    echo ""
    echo "Please compile the project first using:"
    echo "  ./compile.sh"
    echo ""
    exit 1
fi
