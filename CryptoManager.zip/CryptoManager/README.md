# 🔒 Crypto Manager Pro

## Përshkrimi
Crypto Manager Pro është një aplikacion profesional Java me GUI Swing për menaxhimin e kriptografisë. Aplikacioni ofron funksionalitete të plota për enkriptim, dekriptim, hashing dhe gjenerimin e çelësave me një interface modern dhe intuitiv.

## ✨ Funksionalitetet

### 1. 🔐 Enkriptim/Dekriptim
- **Algoritme të Suportuara:**
  - AES-256 (Advanced Encryption Standard)
  - AES-128
  - DES (Data Encryption Standard)
  - 3DES (Triple DES)
  - RSA (Rivest–Shamir–Adleman)
- Enkriptim dhe dekriptim teksti
- Gjenerim automatik i çelësave
- Suport për çelësa të ndryshëm

### 2. 🔨 Hashing
- **Algoritme të Suportuara:**
  - SHA-256
  - SHA-512
  - SHA-384
  - SHA-1
  - MD5
- Hash generation për tekst
- Kopjim i lehtë i hash-it
- Verifikim i integritetit

### 3. 🔑 Gjenerimi i Çelësave
- Gjenerim çelësash simetrikë
- Gjenerim çelësash asimetrikë (RSA 2048-bit)
- Formate të ndryshme: Hex, Base64, Raw
- Gjatësi të ndryshme: 128-bit, 192-bit, 256-bit, 512-bit
- Ruajtje e çelësave në file

### 4. 📁 Enkriptim File-sh
- Enkriptim dhe dekriptim i file-ve të çfarëdo lloji
- Progress bar për monitorim
- Log për gjurmim të procesit
- Suport për file të mëdhenj

### 5. ℹ️ Informacion
- Informacion i detajuar për aplikacionin
- Udhëzime për përdorim
- Këshilla për siguri

## 🎨 Dizajni

Aplikacioni ka një dizajn modern dhe profesional me:
- Color scheme të harmonizuar
- Interface intuitiv dhe user-friendly
- Butona me hover effects
- Card-based layout
- Typography e qartë dhe e lexueshme
- Responsive components

## 📋 Kërkesat

- Java Development Kit (JDK) 8 ose më të ri
- Java Runtime Environment (JRE) për ekzekutim

## 🚀 Si të Kompiloni

### Windows:
```bash
compile.bat
```

### Linux/Mac:
```bash
chmod +x compile.sh
./compile.sh
```

Ose manualisht:
```bash
cd src
javac com/cryptomanager/*.java
```

## ▶️ Si të Ekzekutoni

### Windows:
```bash
run.bat
```

### Linux/Mac:
```bash
chmod +x run.sh
./run.sh
```

Ose manualisht:
```bash
cd src
java com.cryptomanager.CryptoManagerApp
```

## 📦 Struktura e Projektit

```
CryptoManager/
├── src/
│   └── com/
│       └── cryptomanager/
│           ├── CryptoManagerApp.java    # Main aplikacioni
│           ├── CryptoEngine.java        # Motori i kriptografisë
│           └── FileEncryptor.java       # Enkriptim file-sh
├── README.md                            # Ky file
├── compile.bat                          # Script për Windows
├── compile.sh                           # Script për Linux/Mac
├── run.bat                              # Ekzekutim për Windows
└── run.sh                               # Ekzekutim për Linux/Mac
```

## 🔐 Siguria

### ⚠️ Këshilla të Rëndësishme:
1. **Përdorni çelësa të fortë**: Çelësat duhet të jenë të rastësishëm dhe të gjatë
2. **Ruani çelësat**: Mbajini çelësat në vende të sigurta, përdorni password manager
3. **Mos ndani çelësat**: Asnjëherë mos i ndani çelësat me të tjerë
4. **Backup**: Bëni backup të file-ve të rëndësishëm para enkriptimit
5. **Testoni**: Testoni enkriptimin/dekriptimin me file të vogla fillimisht
6. **RSA Keys**: Çelësat privatë RSA duhet të mbahen absolutisht sekret

### 🛡️ Best Practices:
- Përdorni AES-256 për sigurinë më të lartë
- Përdorni SHA-256 ose SHA-512 për hashing
- Ndërroni çelësat rregullisht
- Mos ri-përdorni çelësat për file të ndryshme
- Për RSA, përdorni çelësa të paktën 2048-bit

## 🧪 Shembuj Përdorimi

### Enkriptim Teksti:
1. Shkruani tekstin në fushën e hyrjes
2. Zgjidhni algoritmin (p.sh. AES-256)
3. Shkruani çelësin ose gjeneroni një të ri
4. Klikoni "Processo"
5. Kopjoni rezultatin e enkriptuar

### Hashing:
1. Shkruani tekstin për hash
2. Zgjidhni algoritmin (p.sh. SHA-256)
3. Klikoni "Gjeneroj Hash"
4. Kopjoni hash-in

### Gjenerim Çelësash:
1. Zgjidhni llojin e çelësit
2. Zgjidhni gjatësinë
3. Klikoni "Gjeneroj Çelës"
4. Ruani ose kopjoni çelësin

### Enkriptim File-sh:
1. Klikoni "Shfleto" dhe zgjidhni file-in
2. Zgjidhni algoritmin
3. Shkruani çelësin
4. Zgjidhni "Enkriptim" ose "Dekriptim"
5. Klikoni "Processo File-in"

## 🐛 Troubleshooting

### Probleme të Mundshme:

**"Gabim: Invalid key length"**
- Zgjidhja: Sigurohuni që çelësi ka gjatësinë e duhur për algoritmin e zgjedhur

**"Gabim: Pad block corrupted"**
- Zgjidhja: Çelësi i dekriptimit nuk është i saktë ose file-i është korruptuar

**"File nuk u gjet"**
- Zgjidhja: Verifikoni që file path-i është i saktë

**"OutOfMemoryError"**
- Zgjidhja: Rrisni heap size: `java -Xmx1024m -cp src com.cryptomanager.CryptoManagerApp`

## 📝 Shënime

- Aplikacioni përdor Java Cryptography Architecture (JCA)
- Të gjitha algoritmet janë të siguruara dhe të testuar
- Enkriptimi i file-ve përdor streaming për file të mëdhenj
- IV (Initialization Vector) gjenerohet automatikisht për CBC mode

## 👨‍💻 Zhvilluar Me

- **Gjuha:** Java
- **GUI Framework:** Swing
- **Kriptografi:** Java Cryptography Extension (JCE)
- **Versioni:** 1.0.0

## 📄 Licenca

© 2024 Crypto Manager Pro. Të gjitha të drejtat e rezervuara.

## 🤝 Kontributi

Për probleme, sugjerime ose kontribute, ju lutem hapni një issue ose pull request.

## ⚖️ Disclaimer

Ky aplikacion është krijuar për qëllime edukative dhe profesionale. Përdoruesi është përgjegjës për përdorimin e duhur të aplikacionit dhe mbrojtjen e çelësave të enkriptimit. Zhvilluesi nuk mban përgjegjësi për humbjen e të dhënave ose keqpërdorimin e aplikacionit.

---

**Faleminderit që përdorni Crypto Manager Pro! 🔒**
