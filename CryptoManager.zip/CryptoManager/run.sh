#!/bin/bash

echo "========================================"
echo " Crypto Manager Pro"
echo "========================================"
echo ""
echo "Starting application..."
echo ""

cd src
java com.cryptomanager.CryptoManagerApp

if [ $? -ne 0 ]; then
    echo ""
    echo "========================================"
    echo " Error starting application!"
    echo "========================================"
    echo ""
    echo "Please make sure you have compiled the project first using:"
    echo "  ./compile.sh"
    echo ""
    exit 1
fi
