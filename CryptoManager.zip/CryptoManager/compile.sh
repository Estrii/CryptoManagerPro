#!/bin/bash

echo "========================================"
echo " Crypto Manager Pro - Compilation"
echo "========================================"
echo ""

cd src
echo "Compiling Java files..."
javac com/cryptomanager/*.java

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================"
    echo " Compilation successful!"
    echo "========================================"
    echo ""
    echo "You can now run the application using:"
    echo "  ./run.sh"
    echo ""
else
    echo ""
    echo "========================================"
    echo " Compilation failed!"
    echo "========================================"
    echo ""
    echo "Please check the error messages above."
    echo ""
    exit 1
fi
