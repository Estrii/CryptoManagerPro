
import javax.crypto.*;
import javax.crypto.spec.*;
import java.io.*;
import java.security.*;
import java.util.Base64;

public class FileEncryptor {
    
    private static final int BUFFER_SIZE = 8192;
    
    public FileEncryptor() {
        // Constructor
    }
    
    // Enkriptimi i file-ve
    public void encryptFile(String inputPath, String outputPath, String key, String algorithm) throws Exception {
        processFile(inputPath, outputPath, key, algorithm, Cipher.ENCRYPT_MODE);
    }
    
    // Dekriptimi i file-ve
    public void decryptFile(String inputPath, String outputPath, String key, String algorithm) throws Exception {
        processFile(inputPath, outputPath, key, algorithm, Cipher.DECRYPT_MODE);
    }
    
    private void processFile(String inputPath, String outputPath, String key, String algorithm, int mode) throws Exception {
        File inputFile = new File(inputPath);
        File outputFile = new File(outputPath);
        
        if (!inputFile.exists()) {
            throw new FileNotFoundException("File nuk u gjet: " + inputPath);
        }
        
        Cipher cipher = getCipher(key, algorithm, mode);
        
        try (FileInputStream fis = new FileInputStream(inputFile);
             FileOutputStream fos = new FileOutputStream(outputFile)) {
            
            if (mode == Cipher.ENCRYPT_MODE && cipher.getIV() != null) {
                fos.write(cipher.getIV());
            }
            
            if (mode == Cipher.DECRYPT_MODE) {
                // Lexo IV nga fillimi i file-it
                byte[] iv = new byte[cipher.getBlockSize()];
                int bytesRead = fis.read(iv);
                if (bytesRead == cipher.getBlockSize()) {
                    IvParameterSpec ivSpec = new IvParameterSpec(iv);
                    SecretKey secretKey = generateSecretKey(key, algorithm);
                    String transformation = getTransformation(algorithm);
                    cipher = Cipher.getInstance(transformation);
                    cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
                }
            }
            
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead;
            
            while ((bytesRead = fis.read(buffer)) != -1) {
                byte[] output = cipher.update(buffer, 0, bytesRead);
                if (output != null) {
                    fos.write(output);
                }
            }
            
            byte[] finalBytes = cipher.doFinal();
            if (finalBytes != null) {
                fos.write(finalBytes);
            }
        }
    }
    
    private Cipher getCipher(String key, String algorithm, int mode) throws Exception {
        String transformation = getTransformation(algorithm);
        SecretKey secretKey = generateSecretKey(key, algorithm);
        
        Cipher cipher = Cipher.getInstance(transformation);
        
        if (mode == Cipher.ENCRYPT_MODE) {
            if (transformation.contains("CBC") || transformation.contains("CFB") || transformation.contains("OFB")) {
                byte[] iv = new byte[cipher.getBlockSize()];
                SecureRandom random = new SecureRandom();
                random.nextBytes(iv);
                IvParameterSpec ivSpec = new IvParameterSpec(iv);
                cipher.init(mode, secretKey, ivSpec);
            } else {
                cipher.init(mode, secretKey);
            }
        }
        
        return cipher;
    }
    
    // Krijon SecretKey nga string
    private SecretKey generateSecretKey(String key, String algorithm) throws Exception {
        byte[] keyBytes;
        
        try {
            keyBytes = Base64.getDecoder().decode(key);
        } catch (Exception e) {
            keyBytes = key.getBytes("UTF-8");
        }
        
        int keyLength = getKeyLength(algorithm);
        byte[] adjustedKey = new byte[keyLength];
        
        if (keyBytes.length >= keyLength) {
            System.arraycopy(keyBytes, 0, adjustedKey, 0, keyLength);
        } else {
            for (int i = 0; i < adjustedKey.length; i++) {
                adjustedKey[i] = keyBytes[i % keyBytes.length];
            }
        }
        
        String algo = getAlgorithmName(algorithm);
        return new SecretKeySpec(adjustedKey, algo);
    }
    
    private int getKeyLength(String algorithm) {
        if (algorithm.contains("256")) {
            return 32;
        } else if (algorithm.contains("192")) {
            return 24;
        } else if (algorithm.contains("128")) {
            return 16;
        } else if (algorithm.contains("DES") && !algorithm.contains("3")) {
            return 8;
        } else if (algorithm.contains("3DES")) {
            return 24;
        }
        return 16;
    }
    
    // Merr emrin e algoritmit
    private String getAlgorithmName(String algorithm) {
        if (algorithm.contains("AES")) {
            return "AES";
        } else if (algorithm.contains("3DES")) {
            return "DESede";
        } else if (algorithm.contains("DES")) {
            return "DES";
        }
        return "AES";
    }
    
    // Merr transformation string
    private String getTransformation(String algorithm) {
        if (algorithm.contains("AES")) {
            return "AES/CBC/PKCS5Padding";
        } else if (algorithm.contains("3DES")) {
            return "DESede/CBC/PKCS5Padding";
        } else if (algorithm.contains("DES")) {
            return "DES/CBC/PKCS5Padding";
        }
        return "AES/CBC/PKCS5Padding";
    }
    
    // Verifikoj nëse një file është i enkriptuar
    public boolean isEncrypted(String filePath) {
        // Kontrollo extension
        return filePath.endsWith(".encrypted");
    }
    
    // Merr madhësinë e file-it në format të lexueshëm
    public String getFileSize(String filePath) {
        File file = new File(filePath);
        long size = file.length();
        
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.2f KB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.2f MB", size / (1024.0 * 1024.0));
        } else {
            return String.format("%.2f GB", size / (1024.0 * 1024.0 * 1024.0));
        }
    }
}
