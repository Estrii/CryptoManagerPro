import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;

public class CryptoManagerApp extends JFrame {
    private JTabbedPane tabbedPane;
    private CryptoEngine cryptoEngine;
    
    // Color Scheme
    private static final Color PRIMARY_COLOR = new Color(45, 52, 54);
    private static final Color SECONDARY_COLOR = new Color(99, 110, 114);
    private static final Color ACCENT_COLOR = new Color(0, 184, 148);
    private static final Color BACKGROUND_COLOR = new Color(241, 242, 246);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color TEXT_COLOR = new Color(45, 52, 54);
    
    public CryptoManagerApp() {
        cryptoEngine = new CryptoEngine();
        initializeUI();
    }
    
    private void initializeUI() {
        setTitle("Crypto Manager Pro - Menaxhuesi i Kriptografise");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        // Set modern look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Main container
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        
        // Header
        JPanel header = createHeader();
        mainPanel.add(header, BorderLayout.NORTH);
        
        // Tabbed pane
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabbedPane.setBackground(BACKGROUND_COLOR);
        
        // Add tabs
        tabbedPane.addTab(" Enkriptim/Dekriptim", createEncryptionPanel());
        tabbedPane.addTab(" Hashing", createHashingPanel());
        tabbedPane.addTab(" Gjenerimi i Celsave", createKeyGenerationPanel());
        tabbedPane.addTab(" Enkriptim File-sh", createFileEncryptionPanel());
        tabbedPane.addTab(" Informacion", createInfoPanel());
        
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY_COLOR);
        header.setPreferredSize(new Dimension(0, 80));
        header.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        
        JLabel titleLabel = new JLabel(" Crypto Manager Pro");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        
        JLabel subtitleLabel = new JLabel("Menaxhimi Profesional i Kriptografise");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(200, 200, 200));
        
        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setBackground(PRIMARY_COLOR);
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);
        
        header.add(titlePanel, BorderLayout.WEST);
        
        return header;
    }
    
    private JPanel createEncryptionPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Control panel
        JPanel controlPanel = new JPanel(new GridLayout(4, 2, 15, 15));
        controlPanel.setBackground(CARD_COLOR);
        controlPanel.setBorder(createCardBorder("Opsionet e Enkriptimit"));
        
        JLabel algLabel = new JLabel("Algoritmi:");
        algLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] algorithms = {"AES-256", "AES-128", "DES", "3DES", "RSA"};
        JComboBox<String> algorithmBox = new JComboBox<>(algorithms);
        algorithmBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JLabel keyLabel = new JLabel("Celsi:");
        keyLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        JPasswordField keyField = new JPasswordField();
        keyField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JLabel modeLabel = new JLabel("Menyra:");
        modeLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] modes = {"Enkriptim", "Dekriptim"};
        JComboBox<String> modeBox = new JComboBox<>(modes);
        modeBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JButton generateKeyBtn = createModernButton("Gjeneroj Celes", ACCENT_COLOR);
        generateKeyBtn.addActionListener(e -> {
            String key = cryptoEngine.generateRandomKey(32);
            keyField.setText(key);
        });
        
        controlPanel.add(algLabel);
        controlPanel.add(algorithmBox);
        controlPanel.add(keyLabel);
        controlPanel.add(keyField);
        controlPanel.add(modeLabel);
        controlPanel.add(modeBox);
        controlPanel.add(new JLabel());
        controlPanel.add(generateKeyBtn);
        
        // Text areas
        JPanel textPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        textPanel.setBackground(BACKGROUND_COLOR);
        
        JPanel inputPanel = new JPanel(new BorderLayout(10, 10));
        inputPanel.setBackground(CARD_COLOR);
        inputPanel.setBorder(createCardBorder("Teksti i Hyrjes"));
        JTextArea inputArea = new JTextArea();
        inputArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);
        JScrollPane inputScroll = new JScrollPane(inputArea);
        inputPanel.add(inputScroll, BorderLayout.CENTER);
        
        JPanel outputPanel = new JPanel(new BorderLayout(10, 10));
        outputPanel.setBackground(CARD_COLOR);
        outputPanel.setBorder(createCardBorder("Rezultati"));
        JTextArea outputArea = new JTextArea();
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        outputArea.setEditable(false);
        JScrollPane outputScroll = new JScrollPane(outputArea);
        outputPanel.add(outputScroll, BorderLayout.CENTER);
        
        textPanel.add(inputPanel);
        textPanel.add(outputPanel);
        
        // Action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        actionPanel.setBackground(BACKGROUND_COLOR);
        
        JButton processBtn = createModernButton("Processo", ACCENT_COLOR);
        processBtn.setPreferredSize(new Dimension(200, 45));
        processBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        
        processBtn.addActionListener(e -> {
            try {
                String input = inputArea.getText();
                String key = new String(keyField.getPassword());
                String algorithm = (String) algorithmBox.getSelectedItem();
                String mode = (String) modeBox.getSelectedItem();
                
                if (input.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Ju lutem shkruani tekstin!", "Gabim", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                if (key.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Ju lutem shkruani çelesin!", "Gabim", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                String result;
                if (mode.equals("Enkriptim")) {
                    result = cryptoEngine.encrypt(input, key, algorithm);
                } else {
                    result = cryptoEngine.decrypt(input, key, algorithm);
                }
                
                outputArea.setText(result);
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Gabim: " + ex.getMessage(), "Gabim", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        
        JButton clearBtn = createModernButton("Pastro", SECONDARY_COLOR);
        clearBtn.setPreferredSize(new Dimension(150, 45));
        clearBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        clearBtn.addActionListener(e -> {
            inputArea.setText("");
            outputArea.setText("");
            keyField.setText("");
        });
        
        actionPanel.add(processBtn);
        actionPanel.add(clearBtn);
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(textPanel, BorderLayout.CENTER);
        panel.add(actionPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createHashingPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Control panel
        JPanel controlPanel = new JPanel(new GridLayout(1, 2, 15, 15));
        controlPanel.setBackground(CARD_COLOR);
        controlPanel.setBorder(createCardBorder("Algoritmi i Hashing"));
        
        JLabel algLabel = new JLabel("Zgjidhni Algoritmin:");
        algLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] algorithms = {"SHA-256", "SHA-512", "SHA-1", "MD5", "SHA-384"};
        JComboBox<String> algorithmBox = new JComboBox<>(algorithms);
        algorithmBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        controlPanel.add(algLabel);
        controlPanel.add(algorithmBox);
        
        // Input panel
        JPanel inputPanel = new JPanel(new BorderLayout(10, 10));
        inputPanel.setBackground(CARD_COLOR);
        inputPanel.setBorder(createCardBorder("Teksti per Hash"));
        JTextArea inputArea = new JTextArea();
        inputArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);
        JScrollPane inputScroll = new JScrollPane(inputArea);
        inputPanel.add(inputScroll, BorderLayout.CENTER);
        
        // Output panel
        JPanel outputPanel = new JPanel(new BorderLayout(10, 10));
        outputPanel.setBackground(CARD_COLOR);
        outputPanel.setBorder(createCardBorder("Hash Rezultati"));
        JTextArea outputArea = new JTextArea(4, 50);
        outputArea.setFont(new Font("Consolas", Font.BOLD, 14));
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        outputArea.setEditable(false);
        outputArea.setForeground(ACCENT_COLOR);
        JScrollPane outputScroll = new JScrollPane(outputArea);
        outputPanel.add(outputScroll, BorderLayout.CENTER);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        
        JButton hashBtn = createModernButton("Gjeneroj Hash", ACCENT_COLOR);
        hashBtn.setPreferredSize(new Dimension(200, 45));
        hashBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        hashBtn.addActionListener(e -> {
            try {
                String input = inputArea.getText();
                if (input.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Ju lutem shkruani tekstin!", "Gabim", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                String algorithm = (String) algorithmBox.getSelectedItem();
                String hash = cryptoEngine.hash(input, algorithm);
                outputArea.setText(hash);
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Gabim: " + ex.getMessage(), "Gabim", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton copyBtn = createModernButton("Kopjo Hash", SECONDARY_COLOR);
        copyBtn.setPreferredSize(new Dimension(150, 45));
        copyBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        copyBtn.addActionListener(e -> {
            String hash = outputArea.getText();
            if (!hash.isEmpty()) {
                java.awt.datatransfer.StringSelection selection = new java.awt.datatransfer.StringSelection(hash);
                java.awt.datatransfer.Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(selection, selection);
                JOptionPane.showMessageDialog(this, "Hash-i u kopjua!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        buttonPanel.add(hashBtn);
        buttonPanel.add(copyBtn);
        
        JPanel contentPanel = new JPanel(new GridLayout(2, 1, 0, 20));
        contentPanel.setBackground(BACKGROUND_COLOR);
        contentPanel.add(inputPanel);
        contentPanel.add(outputPanel);
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createKeyGenerationPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Control panel
        JPanel controlPanel = new JPanel(new GridLayout(3, 2, 15, 15));
        controlPanel.setBackground(CARD_COLOR);
        controlPanel.setBorder(createCardBorder("Opsionet e Gjenerimit"));
        
        JLabel typeLabel = new JLabel("Lloji i Celesit:");
        typeLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] types = {"Celes Simetrik", "Celes Asimetrik (RSA)", "Celes Hex", "Celes Base64"};
        JComboBox<String> typeBox = new JComboBox<>(types);
        typeBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JLabel lengthLabel = new JLabel("Gjatesia (bytes):");
        lengthLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] lengths = {"16 (128-bit)", "24 (192-bit)", "32 (256-bit)", "64 (512-bit)"};
        JComboBox<String> lengthBox = new JComboBox<>(lengths);
        lengthBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JLabel formatLabel = new JLabel("Formati:");
        formatLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] formats = {"Hex", "Base64", "Raw"};
        JComboBox<String> formatBox = new JComboBox<>(formats);
        formatBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        controlPanel.add(typeLabel);
        controlPanel.add(typeBox);
        controlPanel.add(lengthLabel);
        controlPanel.add(lengthBox);
        controlPanel.add(formatLabel);
        controlPanel.add(formatBox);
        
        // Output panel
        JPanel outputPanel = new JPanel(new BorderLayout(10, 10));
        outputPanel.setBackground(CARD_COLOR);
        outputPanel.setBorder(createCardBorder("Celesi i Gjeneruar"));
        
        JTextArea outputArea = new JTextArea(15, 50);
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 13));
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        outputArea.setEditable(false);
        JScrollPane outputScroll = new JScrollPane(outputArea);
        outputPanel.add(outputScroll, BorderLayout.CENTER);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        
        JButton generateBtn = createModernButton("Gjeneroj Celes", ACCENT_COLOR);
        generateBtn.setPreferredSize(new Dimension(200, 45));
        generateBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        generateBtn.addActionListener(e -> {
            try {
                String type = (String) typeBox.getSelectedItem();
                String lengthStr = (String) lengthBox.getSelectedItem();
                int length = Integer.parseInt(lengthStr.split(" ")[0]);
                String format = (String) formatBox.getSelectedItem();
                
                String result = "";
                if (type.contains("Asimetrik")) {
                    result = cryptoEngine.generateRSAKeyPair();
                } else {
                    result = cryptoEngine.generateKey(length, format);
                }
                
                outputArea.setText(result);
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Gabim: " + ex.getMessage(), "Gabim", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        JButton saveBtn = createModernButton("Ruaj Celesin", new Color(52, 152, 219));
        saveBtn.setPreferredSize(new Dimension(150, 45));
        saveBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        saveBtn.addActionListener(e -> {
            String key = outputArea.getText();
            if (!key.isEmpty()) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Ruaj Celesin");
                int result = fileChooser.showSaveDialog(this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    try {
                        java.nio.file.Files.write(fileChooser.getSelectedFile().toPath(), key.getBytes());
                        JOptionPane.showMessageDialog(this, "Celesi u ruajt me sukses!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Gabim ne ruajtje: " + ex.getMessage(), "Gabim", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        
        JButton copyBtn = createModernButton("Kopjo", SECONDARY_COLOR);
        copyBtn.setPreferredSize(new Dimension(150, 45));
        copyBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        copyBtn.addActionListener(e -> {
            String key = outputArea.getText();
            if (!key.isEmpty()) {
                java.awt.datatransfer.StringSelection selection = new java.awt.datatransfer.StringSelection(key);
                java.awt.datatransfer.Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(selection, selection);
                JOptionPane.showMessageDialog(this, "Celesi u kopjua!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        buttonPanel.add(generateBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(copyBtn);
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(outputPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createFileEncryptionPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // File selection
        JPanel filePanel = new JPanel(new BorderLayout(10, 10));
        filePanel.setBackground(CARD_COLOR);
        filePanel.setBorder(createCardBorder("Zgjidhni File-in"));
        
        JTextField filePathField = new JTextField();
        filePathField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        filePathField.setEditable(false);
        
        JButton browseBtn = createModernButton("Shfleto...", new Color(52, 152, 219));
        browseBtn.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                filePathField.setText(fileChooser.getSelectedFile().getAbsolutePath());
            }
        });
        
        JPanel fileSelectPanel = new JPanel(new BorderLayout(10, 0));
        fileSelectPanel.setBackground(CARD_COLOR);
        fileSelectPanel.add(filePathField, BorderLayout.CENTER);
        fileSelectPanel.add(browseBtn, BorderLayout.EAST);
        filePanel.add(fileSelectPanel, BorderLayout.CENTER);
        
        // Options
        JPanel optionsPanel = new JPanel(new GridLayout(3, 2, 15, 15));
        optionsPanel.setBackground(CARD_COLOR);
        optionsPanel.setBorder(createCardBorder("Opsionet"));
        
        JLabel algLabel = new JLabel("Algoritmi:");
        algLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] algorithms = {"AES-256", "AES-128", "DES"};
        JComboBox<String> algorithmBox = new JComboBox<>(algorithms);
        algorithmBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JLabel keyLabel = new JLabel("Celesi:");
        keyLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        JPasswordField keyField = new JPasswordField();
        keyField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        JLabel modeLabel = new JLabel("Veprimi:");
        modeLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        String[] modes = {"Enkriptim", "Dekriptim"};
        JComboBox<String> modeBox = new JComboBox<>(modes);
        modeBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        optionsPanel.add(algLabel);
        optionsPanel.add(algorithmBox);
        optionsPanel.add(keyLabel);
        optionsPanel.add(keyField);
        optionsPanel.add(modeLabel);
        optionsPanel.add(modeBox);
        
        // Progress
        JPanel progressPanel = new JPanel(new BorderLayout(10, 10));
        progressPanel.setBackground(CARD_COLOR);
        progressPanel.setBorder(createCardBorder("Progresi"));
        
        JProgressBar progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        progressBar.setForeground(ACCENT_COLOR);
        
        JTextArea logArea = new JTextArea(8, 50);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        
        progressPanel.add(progressBar, BorderLayout.NORTH);
        progressPanel.add(logScroll, BorderLayout.CENTER);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        
        JButton processBtn = createModernButton("Processo File-in", ACCENT_COLOR);
        processBtn.setPreferredSize(new Dimension(200, 45));
        processBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        processBtn.addActionListener(e -> {
            String filePath = filePathField.getText();
            if (filePath.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ju lutem zgjidhni nje file!", "Gabim", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            String key = new String(keyField.getPassword());
            if (key.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ju lutem shkruani çelesin!", "Gabim", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            SwingWorker<Void, String> worker = new SwingWorker<>() {
                @Override
                protected Void doInBackground() throws Exception {
                    publish("Duke filluar procesimin...\n");
                    progressBar.setValue(10);
                    
                    String mode = (String) modeBox.getSelectedItem();
                    String algorithm = (String) algorithmBox.getSelectedItem();
                    
                    FileEncryptor encryptor = new FileEncryptor();
                    publish("Duke lexuar file-in...\n");
                    progressBar.setValue(30);
                    
                    String outputPath;
                    if (mode.equals("Enkriptim")) {
                        outputPath = filePath + ".encrypted";
                        publish("Duke enkriptuar...\n");
                        encryptor.encryptFile(filePath, outputPath, key, algorithm);
                    } else {
                        outputPath = filePath.replace(".encrypted", ".decrypted");
                        publish("Duke dekriptuar...\n");
                        encryptor.decryptFile(filePath, outputPath, key, algorithm);
                    }
                    
                    progressBar.setValue(100);
                    publish("Perfundoi me sukses!\n");
                    publish("File-i u ruajt ne: " + outputPath + "\n");
                    
                    return null;
                }
                
                @Override
                protected void process(java.util.List<String> chunks) {
                    for (String msg : chunks) {
                        logArea.append(msg);
                    }
                }
                
                @Override
                protected void done() {
                    try {
                        get();
                        JOptionPane.showMessageDialog(CryptoManagerApp.this, "Procesi perfundoi me sukses!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(CryptoManagerApp.this, "Gabim: " + ex.getMessage(), "Gabim", JOptionPane.ERROR_MESSAGE);
                        logArea.append("GABIM: " + ex.getMessage() + "\n");
                    }
                }
            };
            
            worker.execute();
        });
        
        JButton clearBtn = createModernButton("Pastro", SECONDARY_COLOR);
        clearBtn.setPreferredSize(new Dimension(150, 45));
        clearBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        clearBtn.addActionListener(e -> {
            filePathField.setText("");
            keyField.setText("");
            logArea.setText("");
            progressBar.setValue(0);
        });
        
        buttonPanel.add(processBtn);
        buttonPanel.add(clearBtn);
        
        JPanel centerPanel = new JPanel(new GridLayout(2, 1, 0, 20));
        centerPanel.setBackground(BACKGROUND_COLOR);
        centerPanel.add(optionsPanel);
        centerPanel.add(progressPanel);
        
        panel.add(filePanel, BorderLayout.NORTH);
        panel.add(centerPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createInfoPanel() {
        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        JPanel infoCard = new JPanel(new BorderLayout(15, 15));
        infoCard.setBackground(CARD_COLOR);
        infoCard.setBorder(createCardBorder("Rreth Aplikacionit"));
        
        JTextArea infoArea = new JTextArea();
        infoArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        infoArea.setEditable(false);
        infoArea.setLineWrap(true);
        infoArea.setWrapStyleWord(true);
        infoArea.setBackground(CARD_COLOR);
        infoArea.setText(
            "CRYPTO MANAGER PRO\n" +
            "Versioni: 1.0.0\n\n" +
            " PERSHKRIMI:\n" +
            "Crypto Manager Pro eshte nje aplikacion profesional per menaxhimin e kriptografise.\n" +
            "Aplikacioni ofron funksionalitete te plota per enkriptim, dekriptim, hashing dhe gjenerimin e çelesave.\n\n" +
            "FUNKSIONALITETET:\n" +
            "Enkriptim/Dekriptim me AES-256, AES-128, DES, 3DES, RSA\n" +
            "Hashing me SHA-256, SHA-512, SHA-1, MD5, SHA-384\n" +
            "Gjenerim Celesash simetrike dhe asimetrike\n" +
            "Enkriptim dhe dekriptim file-sh\n" +
            "Interface modern dhe intuitiv\n\n" +
            "ALGORITMET E SUPORTUARA:\n" +
            "AES (Advanced Encryption Standard) - 128, 192, 256 bit\n" +
            "DES (Data Encryption Standard)\n" +
            "3DES (Triple DES)\n" +
            "RSA (Rivest Shamir Adleman)\n" +
            "SHA (Secure Hash Algorithm) - 1, 256, 384, 512\n" +
            "MD5 (Message Digest Algorithm 5)\n\n" +
            "SIGURIA:\n" +
            "Perdorni Celesa te forte dhe unike\n" +
            "Ruani Celesat ne vende te sigurta\n" +
            "Mos i ndani çelesat me te tjere\n" +
            "Backup-oni file-t e rendesishem para enkriptimit\n\n" +
            "ZHVILLUAR ME:\n" +
            "Java Programming Language\n" +
            "Swing GUI Framework\n" +
            "Java Cryptography Architecture (JCA)\n\n" +
            "� 2026 Crypto Manager Pro. Te gjitha te drejtat e rezervuara."
        );
        
        JScrollPane scrollPane = new JScrollPane(infoArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        infoCard.add(scrollPane, BorderLayout.CENTER);
        
        panel.add(infoCard, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JButton createModernButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }
    
    private Border createCardBorder(String title) {
        Border outer = BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );
        
        TitledBorder titledBorder = BorderFactory.createTitledBorder(
            outer,
            title,
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 16),
            PRIMARY_COLOR
        );
        
        return titledBorder;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CryptoManagerApp app = new CryptoManagerApp();
            app.setVisible(true);
        });
    }
}
