
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;
import java.security.spec.*;
import java.util.Base64;


public class CryptoEngine {
    
    public CryptoEngine() {
        // Constructor
    }
    
    // Enkriptim teksti
    public String encrypt(String plainText, String key, String algorithm) throws Exception {
        if (algorithm.contains("RSA")) {
            return encryptRSA(plainText, key);
        } else {
            return encryptSymmetric(plainText, key, algorithm);
        }
    }
    
    // Dekriptim teksti
    public String decrypt(String encryptedText, String key, String algorithm) throws Exception {
        if (algorithm.contains("RSA")) {
            return decryptRSA(encryptedText, key);
        } else {
            return decryptSymmetric(encryptedText, key, algorithm);
        }
    }
    
    // Enkriptim simetrik
    private String encryptSymmetric(String plainText, String key, String algorithm) throws Exception {
        String transformation = getTransformation(algorithm);
        SecretKey secretKey = generateSecretKey(key, algorithm);
        
        Cipher cipher = Cipher.getInstance(transformation);
        
        if (transformation.contains("CBC") || transformation.contains("CFB") || transformation.contains("OFB")) {
            // Gjeneroj IV për mode që kërkojnë IV
            byte[] iv = new byte[cipher.getBlockSize()];
            SecureRandom random = new SecureRandom();
            random.nextBytes(iv);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
            byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));
            
            // Kombinoj IV + encrypted data
            byte[] combined = new byte[iv.length + encryptedBytes.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(encryptedBytes, 0, combined, iv.length, encryptedBytes.length);
            
            return Base64.getEncoder().encodeToString(combined);
        } else {
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));
            return Base64.getEncoder().encodeToString(encryptedBytes);
        }
    }
    
    // Dekriptim simetrik
    private String decryptSymmetric(String encryptedText, String key, String algorithm) throws Exception {
        String transformation = getTransformation(algorithm);
        SecretKey secretKey = generateSecretKey(key, algorithm);
        
        Cipher cipher = Cipher.getInstance(transformation);
        byte[] combined = Base64.getDecoder().decode(encryptedText);
        
        if (transformation.contains("CBC") || transformation.contains("CFB") || transformation.contains("OFB")) {
            // Ndaj IV dhe encrypted data
            byte[] iv = new byte[cipher.getBlockSize()];
            byte[] encryptedBytes = new byte[combined.length - iv.length];
            
            System.arraycopy(combined, 0, iv, 0, iv.length);
            System.arraycopy(combined, iv.length, encryptedBytes, 0, encryptedBytes.length);
            
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
            
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            return new String(decryptedBytes, "UTF-8");
        } else {
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedBytes = cipher.doFinal(combined);
            return new String(decryptedBytes, "UTF-8");
        }
    }
    
    // Enkriptim RSA
    private String encryptRSA(String plainText, String publicKeyStr) throws Exception {
        // Për simplicitet, përdor çelës të gjeneruar në kohë
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair keyPair = keyGen.generateKeyPair();
        
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, keyPair.getPublic());
        
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
    
    // Dekriptim RSA
    private String decryptRSA(String encryptedText, String privateKeyStr) throws Exception {
        return "RSA dekriptimi kerkon celsa te vecanta. Perdorni Gjenerimin e celsave per RSA.";
    }
    
    // Hash funksioni
    public String hash(String text, String algorithm) throws Exception {
        String algo = algorithm.replace("-", "");
        MessageDigest digest = MessageDigest.getInstance(algo);
        byte[] hashBytes = digest.digest(text.getBytes("UTF-8"));
        
        // Kthej si hex string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
    
    public String generateRandomKey(int length) {
        byte[] key = new byte[length];
        SecureRandom random = new SecureRandom();
        random.nextBytes(key);
        return Base64.getEncoder().encodeToString(key);
    }
    
    public String generateKey(int length, String format) {
        byte[] key = new byte[length];
        SecureRandom random = new SecureRandom();
        random.nextBytes(key);
        
        switch (format) {
            case "Hex":
                return bytesToHex(key);
            case "Base64":
                return Base64.getEncoder().encodeToString(key);
            default:
                return new String(key);
        }
    }
    
    // Gjeneroj RSA key pair
    public String generateRSAKeyPair() {
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(2048, new SecureRandom());
            KeyPair keyPair = keyGen.generateKeyPair();
            
            String publicKey = Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded());
            String privateKey = Base64.getEncoder().encodeToString(keyPair.getPrivate().getEncoded());
            
            StringBuilder result = new StringBuilder();
            result.append("=== PUBLIC KEY (2048-bit RSA) ===\n\n");
            result.append(formatKey(publicKey, 64));
            result.append("\n\n");
            result.append("=== PRIVATE KEY (2048-bit RSA) ===\n\n");
            result.append(formatKey(privateKey, 64));
            result.append("\n\n");
            result.append("KUJDES: Ruani celsin privat ne vend te sigurt!\n");
            result.append("Celsi publik mund te ndahet, por celsi privat duhet mbajtur sekret.");
            
            return result.toString();
        } catch (Exception e) {
            return "Gabim ne gjenerimin e celsave RSA: " + e.getMessage();
        }
    }
    
    private String formatKey(String key, int lineLength) {
        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < key.length(); i += lineLength) {
            int end = Math.min(i + lineLength, key.length());
            formatted.append(key.substring(i, end)).append("\n");
        }
        return formatted.toString();
    }
    
    // Bytes to hex
    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString().toUpperCase();
    }
    
    // Krijon SecretKey nga string
    private SecretKey generateSecretKey(String key, String algorithm) throws Exception {
        byte[] keyBytes;
        
        try {
            keyBytes = Base64.getDecoder().decode(key);
        } catch (Exception e) {
            keyBytes = key.getBytes("UTF-8");
        }
        
        // Adjust key length sipas algoritmit
        int keyLength = getKeyLength(algorithm);
        byte[] adjustedKey = new byte[keyLength];
        
        if (keyBytes.length >= keyLength) {
            System.arraycopy(keyBytes, 0, adjustedKey, 0, keyLength);
        } else {
            for (int i = 0; i < adjustedKey.length; i++) {
                adjustedKey[i] = keyBytes[i % keyBytes.length];
            }
        }
        
        String algo = getAlgorithmName(algorithm);
        return new SecretKeySpec(adjustedKey, algo);
    }
    
    private int getKeyLength(String algorithm) {
        if (algorithm.contains("256")) {
            return 32; // 256 bits
        } else if (algorithm.contains("192")) {
            return 24; // 192 bits
        } else if (algorithm.contains("128")) {
            return 16; // 128 bits
        } else if (algorithm.contains("DES") && !algorithm.contains("3")) {
            return 8; // 64 bits per DES
        } else if (algorithm.contains("3DES")) {
            return 24; // 192 bits per 3DES
        }
        return 16; // default 128 bits
    }
    
    // Merr emrin e algoritmit
    private String getAlgorithmName(String algorithm) {
        if (algorithm.contains("AES")) {
            return "AES";
        } else if (algorithm.contains("3DES")) {
            return "DESede";
        } else if (algorithm.contains("DES")) {
            return "DES";
        }
        return "AES"; // default
    }
    
    // Merr transformation string
    private String getTransformation(String algorithm) {
        if (algorithm.contains("AES")) {
            return "AES/CBC/PKCS5Padding";
        } else if (algorithm.contains("3DES")) {
            return "DESede/CBC/PKCS5Padding";
        } else if (algorithm.contains("DES")) {
            return "DES/CBC/PKCS5Padding";
        }
        return "AES/CBC/PKCS5Padding"; // default
    }
}
